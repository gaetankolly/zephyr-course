#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/logging/log.h>

#include <aht10/aht10.h>

LOG_MODULE_REGISTER(app, LOG_LEVEL_INF);

static const struct device *const env_sensor = DEVICE_DT_GET(DT_NODELABEL(env_sensor));

int main(void)
{
	struct aht10_status status;
	struct sensor_value temp, hum, dew;

	if (!device_is_ready(env_sensor)) {
		LOG_ERR("%s is not ready", env_sensor->name);
		return 0;
	}

	/* Device-specific API */
	if (aht10_get_status(env_sensor, &status) == 0) {
		LOG_INF("%s ready, status 0x%02x (calibrated: %s)", env_sensor->name, status.raw,
			status.calibrated ? "yes" : "no");
	}

	/* Standard API, plus our private dew point channel */
	if (sensor_sample_fetch(env_sensor) == 0) {
		sensor_channel_get(env_sensor, SENSOR_CHAN_AMBIENT_TEMP, &temp);
		sensor_channel_get(env_sensor, SENSOR_CHAN_HUMIDITY, &hum);
		sensor_channel_get(env_sensor, (enum sensor_channel)SENSOR_CHAN_AHT10_DEW_POINT, &dew);

		LOG_INF("temperature %.2f C, humidity %.2f %%RH, dew point %.2f C",
			sensor_value_to_double(&temp), sensor_value_to_double(&hum),
			sensor_value_to_double(&dew));
	}

	return 0;
}
