/*
 * "aht10" shell commands: one command per driver extension.
 */

#include <zephyr/kernel.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/shell/shell.h>

#include <aht10/aht10.h>

static const struct device *const env_sensor = DEVICE_DT_GET(DT_NODELABEL(env_sensor));

/* Print a sensor_value with 2 decimals, handling negative values */
static void print_value(const struct shell *sh, const char *label, const struct sensor_value *val,
			const char *unit)
{
	int64_t micro = sensor_value_to_micro(val);
	const char *sign = micro < 0 ? "-" : "";

	if (micro < 0) {
		micro = -micro;
	}

	shell_print(sh, "%-12s %s%u.%02u %s", label, sign, (uint32_t)(micro / 1000000),
		    (uint32_t)((micro % 1000000) / 10000), unit);
}

static int cmd_read(const struct shell *sh, size_t argc, char **argv)
{
	struct sensor_value temp, hum, dew;
	int ret;

	ret = sensor_sample_fetch(env_sensor);
	if (ret < 0) {
		shell_error(sh, "fetch failed (%d)", ret);
		return ret;
	}

	sensor_channel_get(env_sensor, SENSOR_CHAN_AMBIENT_TEMP, &temp);
	sensor_channel_get(env_sensor, SENSOR_CHAN_HUMIDITY, &hum);
	/* Private channel: same call, driver-specific value */
	sensor_channel_get(env_sensor, (enum sensor_channel)SENSOR_CHAN_AHT10_DEW_POINT, &dew);

	print_value(sh, "temperature", &temp, "C");
	print_value(sh, "humidity", &hum, "%RH");
	print_value(sh, "dew point", &dew, "C");

	return 0;
}

static int cmd_status(const struct shell *sh, size_t argc, char **argv)
{
	struct aht10_status status;
	int ret;

	ret = aht10_get_status(env_sensor, &status);
	if (ret < 0) {
		shell_error(sh, "status read failed (%d)", ret);
		return ret;
	}

	shell_print(sh, "status     0x%02x", status.raw);
	shell_print(sh, "busy       %s", status.busy ? "yes" : "no");
	shell_print(sh, "calibrated %s", status.calibrated ? "yes" : "no");

	return 0;
}

static int cmd_reset(const struct shell *sh, size_t argc, char **argv)
{
	int ret;

	ret = aht10_soft_reset(env_sensor);
	if (ret < 0) {
		shell_error(sh, "reset failed (%d)", ret);
		return ret;
	}

	shell_print(sh, "%s reset and re-initialized", env_sensor->name);
	return 0;
}

static int cmd_raw(const struct shell *sh, size_t argc, char **argv)
{
	uint32_t raw_hum, raw_temp;
	int ret;

	ret = sensor_sample_fetch(env_sensor);
	if (ret < 0) {
		shell_error(sh, "fetch failed (%d)", ret);
		return ret;
	}

	aht10_get_raw(env_sensor, &raw_hum, &raw_temp);
	shell_print(sh, "humidity    0x%05x", raw_hum);
	shell_print(sh, "temperature 0x%05x", raw_temp);

	return 0;
}

SHELL_STATIC_SUBCMD_SET_CREATE(sub_aht10,
	SHELL_CMD(read, NULL, "Read temperature, humidity and dew point", cmd_read),
	SHELL_CMD(status, NULL, "Print the chip status byte", cmd_status),
	SHELL_CMD(reset, NULL, "Soft-reset and re-initialize the chip", cmd_reset),
	SHELL_CMD(raw, NULL, "Print the 20-bit raw values", cmd_raw),
	SHELL_SUBCMD_SET_END
);

SHELL_CMD_REGISTER(aht10, &sub_aht10, "AHT10 temperature and humidity sensor", NULL);
