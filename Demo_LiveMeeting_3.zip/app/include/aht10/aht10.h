/*
 * Aosong AHT10: extensions on top of the standard Sensor API.
 */

#ifndef AHT10_AHT10_H_
#define AHT10_AHT10_H_

#include <stdbool.h>
#include <stdint.h>
#include <zephyr/device.h>
#include <zephyr/drivers/sensor.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Extension 1: private sensor channels.
 *
 * Values only this sensor provides, read with the regular
 * sensor_channel_get().
 */
enum sensor_channel_aht10 {
	/* Dew point in degrees Celsius, computed from temperature and humidity */
	SENSOR_CHAN_AHT10_DEW_POINT = SENSOR_CHAN_PRIV_START,
};

/*
 * Extension 2: device-specific functions.
 *
 * Actions and state that are not a measurement. Every function returns
 * -ENOTSUP when dev is not an AHT10.
 */

struct aht10_status {
	uint8_t raw;     /* Status byte as read from the chip */
	bool busy;       /* Measurement in progress */
	bool calibrated; /* Factory calibration coefficients loaded */
};

/* True if dev is an instance of this driver */
bool aht10_is_device(const struct device *dev);

/* Soft-reset the chip and reload its calibration coefficients */
int aht10_soft_reset(const struct device *dev);

/* Read the status byte from the chip */
int aht10_get_status(const struct device *dev, struct aht10_status *status);

/* 20-bit raw values of the last sample_fetch(), before any conversion */
int aht10_get_raw(const struct device *dev, uint32_t *humidity, uint32_t *temperature);

#ifdef __cplusplus
}
#endif

#endif /* AHT10_AHT10_H_ */
