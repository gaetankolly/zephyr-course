/*
 * Aosong AHT10 temperature and humidity sensor driver.
 */

#include <zephyr/drivers/i2c.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/kernel.h>
#include <zephyr/logging/log.h>
#include <zephyr/sys/byteorder.h>
#if defined(CONFIG_AHT10_CRC)
#include <zephyr/sys/crc.h>
#endif
#include <math.h>

#include <aht10/aht10.h>

#define DT_DRV_COMPAT aosong_aht10
LOG_MODULE_REGISTER(aht10, CONFIG_SENSOR_LOG_LEVEL);

/* Commands (datasheet v1.1, section 5) */
#define AHT10_CMD_INIT       0xE1, 0x08, 0x00
#define AHT10_CMD_MEASURE    0xAC, 0x33, 0x00
#define AHT10_CMD_SOFT_RESET 0xBA

/* Status byte: first byte of every read */
#define AHT10_STATUS_BUSY BIT(7)
#define AHT10_STATUS_CAL  BIT(3)

/* Timings (ms) */
#define AHT10_POWER_ON_MS    100
#define AHT10_SOFT_RESET_MS  20
#define AHT10_INIT_MS        10
#define AHT10_MEASUREMENT_MS 80

/* 6 data bytes; AHT20-class chips append a CRC8 */
#define AHT10_FRAME_LEN 7
#define AHT10_CRC_POLY  0x31 /* x^8 + x^5 + x^4 + 1 */

struct aht10_config {
	struct i2c_dt_spec i2c;
	int32_t temp_offset_milli; /* from DTS */
};

struct aht10_data {
	struct k_mutex lock;
	uint8_t status;
	uint32_t raw_humidity;    /* 20 bit */
	uint32_t raw_temperature; /* 20 bit */
	int64_t temp_offset_micro;
	int64_t hum_offset_micro;
};

static int aht10_write_cmd(const struct device *dev, const uint8_t *cmd, size_t len)
{
	const struct aht10_config *cfg = dev->config;

	return i2c_write_dt(&cfg->i2c, cmd, len);
}

static int aht10_read_status(const struct device *dev, uint8_t *status)
{
	const struct aht10_config *cfg = dev->config;

	return i2c_read_dt(&cfg->i2c, status, 1);
}

/*
 * AHT20-class chips come up calibrated (status 0x18) and NACK the init
 * command. Original AHT10s need it. Only send it when the CAL bit is clear.
 */
static int aht10_chip_init(const struct device *dev)
{
	static const uint8_t init_cmd[] = {AHT10_CMD_INIT};
	uint8_t status;
	int ret;

	ret = aht10_read_status(dev, &status);
	if (ret < 0) {
		LOG_ERR("status read failed (%d)", ret);
		return ret;
	}

	if (status & AHT10_STATUS_CAL) {
		return 0;
	}

	ret = aht10_write_cmd(dev, init_cmd, sizeof(init_cmd));
	if (ret < 0) {
		LOG_ERR("init command failed (%d)", ret);
		return ret;
	}
	k_msleep(AHT10_INIT_MS);

	ret = aht10_read_status(dev, &status);
	if (ret < 0) {
		return ret;
	}

	if (!(status & AHT10_STATUS_CAL)) {
		LOG_ERR("calibration coefficients not loaded (status 0x%02x)", status);
		return -EIO;
	}

	return 0;
}

static int aht10_sample_fetch(const struct device *dev, enum sensor_channel chan)
{
	static const uint8_t measure_cmd[] = {AHT10_CMD_MEASURE};
	const struct aht10_config *cfg = dev->config;
	struct aht10_data *data = dev->data;
	uint8_t frame[AHT10_FRAME_LEN];
	int ret;

	if (chan != SENSOR_CHAN_ALL && chan != SENSOR_CHAN_AMBIENT_TEMP &&
	    chan != SENSOR_CHAN_HUMIDITY && chan != (enum sensor_channel)SENSOR_CHAN_AHT10_DEW_POINT) {
		return -ENOTSUP;
	}

	k_mutex_lock(&data->lock, K_FOREVER);

	ret = aht10_write_cmd(dev, measure_cmd, sizeof(measure_cmd));
	if (ret < 0) {
		goto out;
	}
	k_msleep(AHT10_MEASUREMENT_MS);

	ret = i2c_read_dt(&cfg->i2c, frame, sizeof(frame));
	if (ret < 0) {
		goto out;
	}

	if (frame[0] & AHT10_STATUS_BUSY) {
		ret = -EBUSY;
		goto out;
	}

#if defined(CONFIG_AHT10_CRC)
	if (crc8(frame, AHT10_FRAME_LEN - 1, AHT10_CRC_POLY, 0xFF, false) !=
	    frame[AHT10_FRAME_LEN - 1]) {
		ret = -EIO;
		goto out;
	}
#endif

	/* [status][hum 19:12][hum 11:4][hum 3:0 | temp 19:16][temp 15:8][temp 7:0][crc] */
	data->status = frame[0];
	data->raw_humidity = sys_get_be24(&frame[1]) >> 4;
	data->raw_temperature = sys_get_be24(&frame[3]) & 0xFFFFF;

out:
	k_mutex_unlock(&data->lock);
	return ret;
}

/* RH [%] = raw / 2^20 * 100, plus the user offset */
static int64_t aht10_humidity_micro(const struct aht10_data *data)
{
	return (((int64_t)data->raw_humidity * 100000000) >> 20) + data->hum_offset_micro;
}

/* T [degC] = raw / 2^20 * 200 - 50, plus the user offset */
static int64_t aht10_temperature_micro(const struct aht10_data *data)
{
	return (((int64_t)data->raw_temperature * 200000000) >> 20) - 50000000 +
	       data->temp_offset_micro;
}

/* Magnus formula, valid for -45..60 degC */
static int aht10_dew_point(const struct aht10_data *data, struct sensor_value *val)
{
	const float b = 17.62f;
	const float c = 243.12f;
	float t = aht10_temperature_micro(data) / 1000000.0f;
	float rh = aht10_humidity_micro(data) / 1000000.0f;
	float gamma;

	if (rh <= 0.0f) {
		return -ERANGE;
	}

	gamma = logf(rh / 100.0f) + (b * t) / (c + t);

	return sensor_value_from_float(val, c * gamma / (b - gamma));
}

static int aht10_channel_get(const struct device *dev, enum sensor_channel chan,
			     struct sensor_value *val)
{
	struct aht10_data *data = dev->data;
	int ret = -ENOTSUP;

	k_mutex_lock(&data->lock, K_FOREVER);

	if (chan == SENSOR_CHAN_AMBIENT_TEMP) {
		ret = sensor_value_from_micro(val, aht10_temperature_micro(data));
	} else if (chan == SENSOR_CHAN_HUMIDITY) {
		ret = sensor_value_from_micro(val, aht10_humidity_micro(data));
	} else if (chan == (enum sensor_channel)SENSOR_CHAN_AHT10_DEW_POINT) {
		ret = aht10_dew_point(data, val);
	}

	k_mutex_unlock(&data->lock);
	return ret;
}

static int64_t *aht10_offset_for(struct aht10_data *data, enum sensor_channel chan)
{
	if (chan == SENSOR_CHAN_AMBIENT_TEMP) {
		return &data->temp_offset_micro;
	}

	if (chan == SENSOR_CHAN_HUMIDITY) {
		return &data->hum_offset_micro;
	}

	return NULL;
}

static int aht10_attr_set(const struct device *dev, enum sensor_channel chan,
			  enum sensor_attribute attr, const struct sensor_value *val)
{
	struct aht10_data *data = dev->data;
	int64_t *offset = aht10_offset_for(data, chan);

	if (attr != SENSOR_ATTR_OFFSET || offset == NULL) {
		return -ENOTSUP;
	}

	k_mutex_lock(&data->lock, K_FOREVER);
	*offset = sensor_value_to_micro(val);
	k_mutex_unlock(&data->lock);

	return 0;
}

static int aht10_attr_get(const struct device *dev, enum sensor_channel chan,
			  enum sensor_attribute attr, struct sensor_value *val)
{
	struct aht10_data *data = dev->data;
	int64_t *offset = aht10_offset_for(data, chan);
	int ret;

	if (attr != SENSOR_ATTR_OFFSET || offset == NULL) {
		return -ENOTSUP;
	}

	k_mutex_lock(&data->lock, K_FOREVER);
	ret = sensor_value_from_micro(val, *offset);
	k_mutex_unlock(&data->lock);

	return ret;
}

static DEVICE_API(sensor, aht10_api) = {
	.sample_fetch = aht10_sample_fetch,
	.channel_get = aht10_channel_get,
	.attr_set = aht10_attr_set,
	.attr_get = aht10_attr_get,
};

/* Device-specific API extensions, declared in <aht10/aht10.h> */

bool aht10_is_device(const struct device *dev)
{
	return dev != NULL && dev->api == &aht10_api;
}

int aht10_soft_reset(const struct device *dev)
{
	static const uint8_t reset_cmd[] = {AHT10_CMD_SOFT_RESET};
	struct aht10_data *data;
	int ret;

	if (!aht10_is_device(dev)) {
		return -ENOTSUP;
	}
	data = dev->data;

	k_mutex_lock(&data->lock, K_FOREVER);

	ret = aht10_write_cmd(dev, reset_cmd, sizeof(reset_cmd));
	if (ret == 0) {
		k_msleep(AHT10_SOFT_RESET_MS);
		ret = aht10_chip_init(dev);
	}

	k_mutex_unlock(&data->lock);
	return ret;
}

int aht10_get_status(const struct device *dev, struct aht10_status *status)
{
	struct aht10_data *data;
	int ret;

	if (!aht10_is_device(dev)) {
		return -ENOTSUP;
	}
	data = dev->data;

	k_mutex_lock(&data->lock, K_FOREVER);
	ret = aht10_read_status(dev, &status->raw);
	k_mutex_unlock(&data->lock);

	if (ret < 0) {
		return ret;
	}

	status->busy = status->raw & AHT10_STATUS_BUSY;
	status->calibrated = status->raw & AHT10_STATUS_CAL;
	return 0;
}

int aht10_get_raw(const struct device *dev, uint32_t *humidity, uint32_t *temperature)
{
	struct aht10_data *data;

	if (!aht10_is_device(dev)) {
		return -ENOTSUP;
	}
	data = dev->data;

	k_mutex_lock(&data->lock, K_FOREVER);
	*humidity = data->raw_humidity;
	*temperature = data->raw_temperature;
	k_mutex_unlock(&data->lock);

	return 0;
}

static int aht10_init(const struct device *dev)
{
	static const uint8_t reset_cmd[] = {AHT10_CMD_SOFT_RESET};
	const struct aht10_config *cfg = dev->config;
	struct aht10_data *data = dev->data;

	if (!i2c_is_ready_dt(&cfg->i2c)) {
		LOG_ERR("I2C bus %s not ready", cfg->i2c.bus->name);
		return -ENODEV;
	}

	k_mutex_init(&data->lock);
	data->temp_offset_micro = (int64_t)cfg->temp_offset_milli * 1000;

	k_msleep(AHT10_POWER_ON_MS);

	/* A soft reset first, in case the MCU rebooted but the sensor did not */
	(void)aht10_write_cmd(dev, reset_cmd, sizeof(reset_cmd));
	k_msleep(AHT10_SOFT_RESET_MS);

	return aht10_chip_init(dev);
}

#define AHT10_DEFINE(inst)                                                                         \
	static struct aht10_data aht10_data_##inst;                                                \
	static const struct aht10_config aht10_config_##inst = {                                   \
		.i2c = I2C_DT_SPEC_INST_GET(inst),                                                 \
		.temp_offset_milli = DT_INST_PROP(inst, temperature_offset_milli_celsius),         \
	};                                                                                         \
	DEVICE_DT_INST_DEFINE(inst, aht10_init, NULL, &aht10_data_##inst, &aht10_config_##inst,    \
			      POST_KERNEL, CONFIG_SENSOR_INIT_PRIORITY, &aht10_api)

DT_INST_FOREACH_STATUS_OKAY(AHT10_DEFINE)
